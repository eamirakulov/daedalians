
	<div class="col-sm-3 sidebar">
		<?php if ( ! dynamic_sidebar( 'primary-sidebar' ) ) : ?>
			<?php dynamic_sidebar( 'primary-sidebar' ); ?>
		<?php endif; ?>
	</div>